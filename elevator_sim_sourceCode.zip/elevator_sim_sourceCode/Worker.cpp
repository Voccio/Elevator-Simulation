#include"Worker.h"

Worker::Worker()
{
	floor = 0;
	lunchStart = 0;
	lunchEnd = 0;
	startWork = 0;
	endWork = 0;
	lunch = false;
	takenLunch = false;
	startTime = 0;
	endTime = 0;
	timer = 0;
	serviceTime = 0;
	coming = true;
	lunchFloor = 0;
}

void Worker::RNGLunchStart()
{
	if(lunch)
	{
		srand(time(NULL));
		lunchStart = (rand() % 15) * 60 + 16200;
	}
}
	
void Worker::RNGLunchEnd()
{
	if(lunch)
	{
		srand(time(NULL));
		lunchEnd = (rand() % 15) * 60 + 18900;
	}
}

void Worker::RNGStartWork(int i)
{
	startWork = (i % 30 + 1) * 60;
}
	
void Worker::EndWork()
{
	endWork = 28800 + startWork + (lunchEnd - lunchStart);
}
		
void Worker::AddStartLunch()
{
	SetTimer(lunchStart);
}
	
int Worker::GetStartWork()
{
	return startWork;
}

int Worker::GetEndWork()
{
	return endWork;
}

bool Worker::TakenLunch()
{
	return takenLunch;
}

void Worker::SetLunch()
{
	lunch = true;
}

void Worker::SetTakenLunch()
{
	takenLunch = true;
}

void Worker::SetFloor(int i)
{
	floor = ((i + 1) % 4) + 1;
}

int Worker::GetFloorW()
{
	return floor;
}

void Worker::SetStart(double masterTime)
{
	startTime = masterTime;
}

void Worker::SetEnd(double elevatorTime)
{
	endTime = elevatorTime;
}

void Worker::ServiceTime()
{
	serviceTime = endTime - startTime;
}

double Worker::GetServiceTime()
{
	return serviceTime;
}

void Worker::DesiredFloorEmpty()
{
	floor = -1;
}

void Worker::SetTimer(double masterTime)
{
	if(lunch)
	{
		if(!takenLunch)
		{
			timer = lunchStart;
		}
		else if(takenLunch)
		{
			timer = endWork;
		}
	}
	else if(!lunch)
	{
		timer = endWork;
	}
}

bool Worker::CompareTime(double masterTime)
{
	if(timer == masterTime)
		return true;
	if(timer < masterTime)
		return false;
	if(timer > masterTime)
		return false;
}

double Worker::GetStartTime()
{
	return startTime;
}

double Worker::GetEndTime()
{
	return endTime;
}

bool Worker::GetComing()
{
	return coming;
}

void Worker::SetComing()
{
	coming = false;
}

void Worker::SetDesiredFloor()
{
	floor = 0;
}

bool Worker::Lunch()
{
	return lunch;
}

void Worker::SetLunchEnd()
{
	timer = lunchEnd;
}

void Worker::TimeEndWork()
{
	timer = endWork;
}

int Worker::ReturnLunchFloor()
{
	return lunchFloor;
}