#include"Passenger.h"

Passenger::Passenger()
{
	desiredFloor = 0;
	timeOnFloor = 0;
	startTime = 0;
	endTime = 0;
	timer = 0;
	serviceTime = 0;
}

void Passenger::RNGDesiredFloor()
{
	srand(time(0));
	desiredFloor = rand() % 4 + 1;
}

void Passenger::RNGTimeOnFloor()
{
	srand(time(0));
	timeOnFloor = (rand() % 30 + 15) * 60;
}

void Passenger::SetStart(double masterTime)
{
	startTime = masterTime;
}

void Passenger::SetEnd(double elevatorTime)
{
	endTime = elevatorTime;
}

void Passenger::ServiceTime()
{
	serviceTime = endTime - startTime;
}

double Passenger::GetServiceTime()
{
	return serviceTime;
}

int Passenger::GetFloor()
{
	return desiredFloor;
}

void Passenger::DesiredFloorEmpty()
{
	desiredFloor = -1;
}

void Passenger::SetTimer(double masterTime)
{
	timer = masterTime;
	timer += timeOnFloor;
}

bool Passenger::CompareTime(double masterTime)
{
	if(timer == masterTime)
		return true;
	if(timer < masterTime)
		return false;
	if(timer > masterTime)
		return false;
}

double Passenger::GetStartTime()
{
	return startTime;
}

double Passenger::GetEndTime()
{
	return endTime;
}

void Passenger::SetDesiredFloor()
{
	desiredFloor = 0;
}