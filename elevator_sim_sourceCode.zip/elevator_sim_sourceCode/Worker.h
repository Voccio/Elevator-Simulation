#include"Passenger.h"

class Worker
{
private:
	int floor;
	int lunchStart;
	int lunchEnd;
	int startWork;
	double endWork;
	bool lunch;
	bool takenLunch;
	bool coming;
	double startTime;
	double endTime;
	double timer;
	double serviceTime;
	int lunchFloor;

public:
	Worker();
	void RNGLunchStart();
	void RNGLunchEnd();
	void RNGStartWork(int i);
	void EndWork();
	void AddStartLunch();
	int GetStartWork();
	int GetEndWork();
	bool TakenLunch();
	void SetLunch();
	void SetTakenLunch();
	void SetFloor(int i);
	int GetFloorW();

	void SetStart(double masterTime);
	void SetEnd(double elevatorTime);
	void ServiceTime();
	double GetServiceTime();
	void DesiredFloorEmpty();
	void SetTimer(double masterTime);
	bool CompareTime(double masterTime);
	double GetStartTime();
	double GetEndTime();
	bool GetComing();
	void SetComing();
	void SetDesiredFloor();
	bool Lunch();
	void SetLunchEnd();
	void TimeEndWork();
	int ReturnLunchFloor();
};