#include"QueTypeW.h"

class Master
{
private:
	double time;
	double endTime;
	bool running;
	int floorSummons[5];
	double numServicedPatrons;
	double avgServiceTime;
	int floorSummonsW[5];
	double shortest;
	double longest;
	float perUnOne;
	int* summonsPerFloor;
public:
	Master();
	~Master();
	void AddTime();
	double GetTime();
	void Running();
	bool GetRunning();
	void AddFloorSummons(int desiredFloor);
	int* GetFloorSummons();
	void SubFloorSummons(int desiredFloor);
	void AddFloorSummonsW(int desiredFloor);
	int* GetFloorSummonsW();
	void SubFloorSummonsW(int desiredFloor);
	void AddServicedPatrons();
	void AverageServiceTimes();
	void GetPatronServiceTime(int serviceTime);
	double GetAverageService();
	int GetNumServiced();
	void LongestOrShortest(int serviceTime);
	int GetLongest();
	int GetShortest();
	void PerUnOne();
	float GetPerUnOne();
	void AddPerUnOne();
	void AddSummonsPerFloor(int floor);
	int* GetSummonsPerFloor();
};