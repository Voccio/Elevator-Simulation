#include"Master.h"

Master::Master()
{
	time = 0;
	endTime = 36000;
	running = true;
	for(int i = 0; i < 5; i++)
		floorSummons[i] = 0;
	for(int i = 0; i < 5; i++)
		floorSummonsW[i] = 0;
	numServicedPatrons = 0;
	avgServiceTime = 0;
	shortest = 0;
	longest = 0;
	perUnOne = 0;
	summonsPerFloor = new int[5];
	for(int i = 0; i < 5; i++)
	{
		summonsPerFloor[i] = 0;
	}
}

void Master::AddTime()
{
	time++;
}

double Master::GetTime()
{
	return time;
}

void Master::Running()
{
	if(time == endTime)
		running = false;
	else
		running = true;
}

bool Master::GetRunning()
{
	return running;
}

void Master::AddFloorSummons(int desiredFloor)
{
	floorSummons[desiredFloor]++;
	AddSummonsPerFloor(desiredFloor);
}

void Master::SubFloorSummons(int desiredFloor)
{
	floorSummons[desiredFloor]--;
}

int* Master::GetFloorSummons()
{
	return floorSummons;
}

void Master::AddServicedPatrons()
{
	numServicedPatrons++;
}

void Master::AverageServiceTimes()
{
	avgServiceTime = (avgServiceTime / numServicedPatrons);
}
	
void Master::GetPatronServiceTime(int serviceTime)
{
	LongestOrShortest(serviceTime);
	avgServiceTime += serviceTime;
}

double Master::GetAverageService()
{
	return avgServiceTime;
}

int Master::GetNumServiced()
{
	return numServicedPatrons;
}

void Master::AddFloorSummonsW(int desiredFloor)
{
	floorSummonsW[desiredFloor]++;
	AddSummonsPerFloor(desiredFloor);
}

void Master::SubFloorSummonsW(int desiredFloor)
{
	floorSummonsW[desiredFloor]--;
}

int* Master::GetFloorSummonsW()
{
	return floorSummonsW;
}

void Master::LongestOrShortest(int serviceTime)
{
	if(serviceTime < shortest)
	{
		shortest = serviceTime;
	}
	if(serviceTime > longest)
	{
		longest = serviceTime;
	}
	if(serviceTime < 60)
	{
		AddPerUnOne();
	}
}

int Master::GetLongest()
{
	return longest;
}

int Master::GetShortest()
{
	return shortest;
}

void Master::PerUnOne()
{
	perUnOne = (perUnOne / numServicedPatrons) * 100;
}

float Master::GetPerUnOne()
{
	return perUnOne;
}

void Master::AddPerUnOne()
{
	perUnOne++;
}

void Master::AddSummonsPerFloor(int floor)
{
	summonsPerFloor[floor]++;
}

int* Master::GetSummonsPerFloor()
{
	return summonsPerFloor;
}

Master::~Master()
{
	delete [] summonsPerFloor;
}