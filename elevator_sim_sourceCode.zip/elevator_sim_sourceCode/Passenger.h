#include<stdlib.h>
#include<stdio.h>
#include<time.h>

class Passenger
{
private:
	int desiredFloor;
	int timeOnFloor;
	double startTime;
	double endTime;
	double timer;
	double serviceTime;

public:
	Passenger();
	void RNGDesiredFloor();
	void RNGTimeOnFloor();
	void SetStart(double masterTime);
	void SetEnd(double elevatorTime);
	void ServiceTime();
	double GetServiceTime();
	int GetFloor();
	void DesiredFloorEmpty();
	void SetTimer(double masterTime);
	bool CompareTime(double masterTime);
	double GetStartTime();
	double GetEndTime();
	void SetDesiredFloor();
};