#include"Elevator.h"

Elevator::Elevator()
{
	currentFloor = 0;
	cap = 0;
	maxCap = 8;
	for(int i = 0; i < 5; i++)
		floorRequests[i] = 0;
	for(int i = 0; i < 5; i++)
		floorRequestsW[i] = 0;
	loadUnload = 3;
	idle = 10;
	traverse = 15;
	time = 1;
	direction = true;
	emptyItemW.DesiredFloorEmpty();
	emptyItem.DesiredFloorEmpty();
	for(int i = 0; i < 8; i++)
		passengers[i] = emptyItem;
	for(int i = 0; i < 8; i++)
		workers[i] = emptyItemW;
	loaded = false;
	numServiced = 0;
}

int Elevator::GetCurrentFloor()
{
	return currentFloor;
}

int Elevator::GetCap()
{
	return cap;
}

double Elevator::GetTime()
{
	return time;
}

bool Elevator::Direction()
{
	return direction;
}
	
void Elevator::LoadUnload()
{
	time += loadUnload;
}

void Elevator::Traverse()
{
	time += traverse;
	if(direction == false)
		currentFloor--;
	else if(direction == true)
		currentFloor++;
}

void Elevator::Idle()
{
	time += idle;
}

bool Elevator::CompareTime(double masterTime)
{
	if(time == masterTime)
		return true;
	if(time < masterTime)
	{
		time = masterTime;
		return true;
	}
}

void Elevator::SetDirection(bool called)
{
	direction = called;
}

void Elevator::AddCap()
{
	cap++;
}

void Elevator::SubCap()
{
	cap--;
}

void Elevator::AddPassenger(Passenger newItem)
{
	for(int i = 0; i < maxCap; i++)
	{
		if(passengers[i].GetFloor() == -1)
		{
			passengers[i] = newItem;
			if(GetCurrentFloor() != 0)
			{
				floorRequests[0]++;
				i = 9;
			}
			else if(GetCurrentFloor() == 0)
			{
				floorRequests[newItem.GetFloor()]++;
				i = 9;
			}
		}
	}
}

int* Elevator::GetFloorRequests()
{
	return floorRequests;
}

Passenger Elevator::SubFloorRequests()
{
	Passenger tempPass;
	floorRequests[currentFloor]--;
	for(int i = 0; i < 8; i++)
	{
		if(passengers[i].GetFloor() == currentFloor)
		{
			tempPass = passengers[i];
			passengers[i] = emptyItem;
			SubCap();
			return tempPass;
		}
	}
}

Worker Elevator::SubFloorRequestsW()
{
	if(GetCurrentFloor() != 0)
	{
		Worker tempPass;
		floorRequestsW[currentFloor]--;
		for(int i = 0; i < 8; i++)
		{
			if(workers[i].GetFloorW() == currentFloor)
			{
				tempPass = workers[i];
				workers[i] = emptyItemW;
				SubCap();
				return tempPass;
			}
		}
	}
	else if(GetCurrentFloor() == 0)
	{
		Worker tempPass;
		floorRequestsW[currentFloor]--;
		for(int i = 0; i < 8; i++)
		{
			if(workers[i].Lunch() && !workers[i].TakenLunch())
			{
				tempPass = workers[i];
				workers[i] = emptyItemW;
				SubCap();
				workers[i].SetLunchEnd();
				return tempPass;
			}
			if(workers[i].Lunch() && workers[i].TakenLunch())
			{
				tempPass = workers[i];
				workers[i] = emptyItemW;
				SubCap();
				return tempPass;
			}
			if(workers[i].GetFloorW() == currentFloor)
			{
				tempPass = workers[i];
				workers[i] = emptyItemW;
				SubCap();
				return tempPass;
			}
		}
	}
}

void Elevator::AddWorker(Worker newItem)
{
	for(int i = 0; i < maxCap; i++)
	{
		if(workers[i].GetFloorW() == -1)
		{
			workers[i] = newItem;
			if(GetCurrentFloor() != 0)
			{
				floorRequestsW[0]++;
				i = 9;
			}
			else if(GetCurrentFloor() == 0)
			{
				floorRequestsW[newItem.GetFloorW()]++;
				i = 9;
			}
		}
	}
}

int* Elevator::GetFloorRequestsW()
{
	return floorRequestsW;
}

bool Elevator::LoadedUnloaded()
{
	return loaded;
}

void Elevator::SetLoaded()
{
	loaded = true;
}

void Elevator::ResetLoaded()
{
	loaded = false;
}

void Elevator::AddServiced()
{
	numServiced++;
}

int Elevator::GetNumServiced()
{
	return numServiced;
}