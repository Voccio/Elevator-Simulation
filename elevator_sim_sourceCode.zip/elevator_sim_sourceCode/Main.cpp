#include<iostream>
#include<conio.h>
#include"Master.h"



int main()
{
	using namespace std;

	int numElev;
	int time;
	int counterP;

	Master master;
	Elevator elevators[40];
	QueType floors[5];
	QueTypeW floorsW[5];
	Passenger passengers[120];
	Passenger tempPassenger;
	Passenger floor1[120];
	Passenger floor2[120];
	Passenger floor3[120];
	Passenger floor4[120];
	Passenger emptyItem;
	Worker workers[400];
	Worker tempWorker;
	Worker emptyItemW;
	Worker floor0W[200];
	Worker floor1W[100];
	Worker floor2W[100];
	Worker floor3W[100];
	Worker floor4W[100];



	counterP = -1;
	time = 0;
	emptyItemW.DesiredFloorEmpty();
	emptyItem.DesiredFloorEmpty();
	for(int i = 0; i < 120; i++)
	{
		floor1[i] = emptyItem;
		floor2[i] = emptyItem;
		floor3[i] = emptyItem;
		floor4[i] = emptyItem;
	}
	for(int i = 0; i < 100; i++)
	{
		floor1W[i] = emptyItemW;
		floor2W[i] = emptyItemW;
		floor3W[i] = emptyItemW;
		floor4W[i] = emptyItemW;
	}
	for(int i = 0; i < 200; i++)
	{
		floor0W[i] = emptyItemW;
	}
	for(int i = 0; i < 400; i++)
	{
		workers[i].RNGStartWork(i);
	}



	cout << "Enter the number of elevators to use for this simulation." << endl << 
		"With a maximum of 10 being used during a simulation run." << endl;
	cin >> numElev;

	
	
	do
	{
		if(master.GetRunning() == true)
			master.AddTime();
		master.Running();
		if(master.GetTime() <= 1800)
		{
			for(int i = 0; i < 400; i ++)
			{
				if(workers[i].GetStartWork() == master.GetTime())
				{ 
					master.AddFloorSummonsW(0);
					workers[i].SetFloor(i);
					if(i % 2 == 0)
						workers[i].SetLunch();
					workers[i].SetStart(master.GetTime());
					workers[i].RNGLunchStart();
					workers[i].RNGLunchEnd();
					workers[i].EndWork();
					floorsW[0].Enqueue(workers[i]);
				}
			}
		}
		if(master.GetTime() >= 1800 && master.GetTime() < 31500)
		{
			time = master.GetTime();
			if(time % 300 == 0)
			{
				counterP++;
				passengers[counterP].RNGDesiredFloor();
				passengers[counterP].RNGTimeOnFloor();
				passengers[counterP].SetStart(master.GetTime());
				floors[0].Enqueue(passengers[counterP]);
				master.AddFloorSummons(0);
			}
		}
		for(int i = 0; i < 200; i++)
		{
			if(floor0W[i].CompareTime(master.GetTime()))
			{
				master.AddFloorSummonsW(0);
				floor0W[i].SetStart(master.GetTime());
				floorsW[0].Enqueue(floor0W[i]);
				floor0W[i] = emptyItemW;
			}
		}
		for(int i = 0; i < 100; i++)
		{
			if(floor1W[i].CompareTime(master.GetTime()))
			{
				master.AddFloorSummonsW(1);
				floor1W[i].SetStart(master.GetTime());
				floorsW[1].Enqueue(floor1W[i]);
				floor1W[i] = emptyItemW;
			}
			if(floor2W[i].CompareTime(master.GetTime()))
			{
				master.AddFloorSummonsW(2);
				floor2W[i].SetStart(master.GetTime());
				floorsW[2].Enqueue(floor2W[i]);
				floor2W[i] = emptyItemW;
			}
			if(floor3W[i].CompareTime(master.GetTime()))
			{
				master.AddFloorSummonsW(3);
				floor3W[i].SetStart(master.GetTime());
				floorsW[3].Enqueue(floor3W[i]);
				floor3W[i] = emptyItemW;
			}
			if(floor4W[i].CompareTime(master.GetTime()))
			{
				master.AddFloorSummonsW(4);
				floor4W[i].SetStart(master.GetTime());
				floorsW[4].Enqueue(floor4W[i]);
				floor4W[i] = emptyItemW;
			}
		}
		for(int i = 0; i < 120; i++)
		{
			if(floor1[i].CompareTime(master.GetTime()))
			{
				master.AddFloorSummons(1);
				floor1[i].SetStart(master.GetTime());
				floors[1].Enqueue(floor1[i]);
				floor1[i] = emptyItem;
			}
			if(floor2[i].CompareTime(master.GetTime()))
			{
				master.AddFloorSummons(2);
				floor2[i].SetStart(master.GetTime());
				floors[2].Enqueue(floor2[i]);
				floor2[i] = emptyItem;
			}
			if(floor3[i].CompareTime(master.GetTime()))
			{
				master.AddFloorSummons(3);
				floor3[i].SetStart(master.GetTime());
				floors[3].Enqueue(floor3[i]);
				floor3[i] = emptyItem;
			}
			if(floor4[i].CompareTime(master.GetTime()))
			{
				master.AddFloorSummons(4);
				floor4[i].SetStart(master.GetTime());
				floors[4].Enqueue(floor4[i]);
				floor4[i] = emptyItem;
			}
		}





		for(int i = 0; i < numElev; i++)
		{
			elevators[i].ResetLoaded();
			if(elevators[i].CompareTime(master.GetTime()))
			{
				if(elevators[i].GetCap() != 0)
				{
					for(int j = 0; j < 5; j++)
					{
						if(elevators[i].GetFloorRequestsW()[j] != 0)
						{
							if(j == elevators[i].GetCurrentFloor())
							{
								for(int k = 0; k < elevators[i].GetFloorRequestsW()[j];)
								{
									elevators[i].LoadUnload();
									if(elevators[i].GetCurrentFloor() == 4)
									{
										elevators[i].SetDirection(false);
									}
									elevators[i].SetLoaded();
									tempWorker = elevators[i].SubFloorRequestsW();
									
										tempWorker.SetTimer(master.GetTime());
										if(!tempWorker.Lunch())
										{
											tempWorker.SetDesiredFloor();
										}
										if(tempWorker.Lunch() && tempWorker.TakenLunch() && elevators[i].GetCurrentFloor() != 0)
										{
											tempWorker.SetDesiredFloor();
										}
										if((tempWorker.Lunch() && !tempWorker.TakenLunch()) && elevators[i].GetCurrentFloor() == 0)
										{
											for(int j = 0; j < 200; j++)
											{
												if(floor0W[j].GetFloorW() == -1)
												{
													tempWorker.SetTakenLunch();
													tempWorker.SetLunchEnd();
													floor0W[j] = tempWorker;
													j = 201;
												}
											}
										}
										if(elevators[i].GetCurrentFloor() == 1)
										{
											for(int j = 0; j < 100; j++)
											{
												if(floor1W[j].GetFloorW() == -1)
												{
													floor1W[j] = tempWorker;
													j = 101;
												}
											}
										}
										else if(elevators[i].GetCurrentFloor() == 2)
										{
											for(int j = 0; j < 100; j++)
											{
												if(floor2W[j].GetFloorW() == -1)
												{
													floor2W[j] = tempWorker;
													j = 101;
												}
											}
										}
										else if(elevators[i].GetCurrentFloor() == 3)
										{
											for(int j = 0; j < 100; j++)
											{
												if(floor3W[j].GetFloorW() == -1)
												{
													floor3W[j] = tempWorker;
													j = 101;
												}
											}
										}
										else if(elevators[i].GetCurrentFloor() == 4)
										{
											for(int j = 0; j < 100; j++)
											{
												if(floor4W[j].GetFloorW() == -1)
												{
													floor4W[j] = tempWorker;
													j = 101;
												}
											}
										}
									}
								} 
							}
						}
					
					for(int j = 0; j < 5; j++)
					{
						if(elevators[i].GetFloorRequests()[j] != 0)
						{
							if(j == elevators[i].GetCurrentFloor())
							{
								for(int k = 0; k < elevators[i].GetFloorRequests()[j];)
								{
									elevators[i].LoadUnload();
									if(elevators[i].GetCurrentFloor() == 4)
									{
										elevators[i].SetDirection(false);
									}
									elevators[i].SetLoaded();
									tempPassenger = elevators[i].SubFloorRequests();
									if(elevators[i].GetCurrentFloor() != 0)
									{
										tempPassenger.SetTimer(master.GetTime());
										tempPassenger.SetDesiredFloor();
										if(elevators[i].GetCurrentFloor() == 1)
										{
											for(int j = 0; j < 120; j++)
											{
												if(floor1[j].GetFloor() == -1)
												{
													floor1[j] = tempPassenger;
													j = 121;
												}
											}
										}
										else if(elevators[i].GetCurrentFloor() == 2)
										{
											for(int j = 0; j < 120; j++)
											{
												if(floor2[j].GetFloor() == -1)
												{
													floor2[j] = tempPassenger;
													j = 121;
												}
											}
										}
										else if(elevators[i].GetCurrentFloor() == 3)
										{
											for(int j = 0; j < 120; j++)
											{
												if(floor3[j].GetFloor() == -1)
												{
													floor3[j] = tempPassenger;
													j = 121;
												}
											}
										}
										else if(elevators[i].GetCurrentFloor() == 4)
										{
											for(int j = 0; j < 120; j++)
											{
												if(floor4[j].GetFloor() == -1)
												{
													floor4[j] = tempPassenger;
													j = 121;
												}
											}
										}
									}
								}
							}
						}
					}
				}
				if(elevators[i].GetCurrentFloor() == 0 || (elevators[i].Direction() == false && elevators[i].GetCap() != 8) || (elevators[i].Direction() == true && elevators[i].GetCap() == 0 
					&& !(master.GetFloorSummons()[1] != 0 && 1 > elevators[i].GetCurrentFloor()) || (master.GetFloorSummons()[2] != 0 && 2 > elevators[i].GetCurrentFloor())
					|| (master.GetFloorSummons()[3] != 0 && 3 > elevators[i].GetCurrentFloor()) || (master.GetFloorSummons()[4] != 0 && 4 > elevators[i].GetCurrentFloor())
					|| (master.GetFloorSummonsW()[1] != 0 && 1 > elevators[i].GetCurrentFloor()) || (master.GetFloorSummonsW()[2] != 0 && 2 > elevators[i].GetCurrentFloor())
					|| (master.GetFloorSummonsW()[3] != 0 && 3 > elevators[i].GetCurrentFloor()) || (master.GetFloorSummonsW()[4] != 0 && 4 > elevators[i].GetCurrentFloor())))
				
				{
					for(int j = 0; j < 5; j++)
					{
						if(master.GetFloorSummonsW()[j] != 0)
						{
							if(j == elevators[i].GetCurrentFloor())
							{
								for(int k = 0; k < master.GetFloorSummonsW()[j] && elevators[i].GetCap() < 8;)  
								{
									elevators[i].AddCap();
									elevators[i].AddServiced();
									elevators[i].SetLoaded();
									tempWorker = floorsW[j].Dequeue();
									tempWorker.SetEnd(elevators[i].GetTime());
									tempWorker.ServiceTime();
									master.GetPatronServiceTime(tempWorker.GetServiceTime());
									elevators[i].AddWorker(tempWorker);
									elevators[i].LoadUnload();
									master.AddServicedPatrons();
									master.SubFloorSummonsW(j);
									if(tempWorker.GetComing())
									{
										tempWorker.SetComing();
									}
									else if(tempWorker.Lunch() && !tempWorker.TakenLunch())
									{
										tempWorker.SetLunchEnd();
									}
									else if(tempWorker.Lunch() && tempWorker.TakenLunch())
									{
										tempWorker.TimeEndWork();
									}
								}	
							}
						}
						if(master.GetFloorSummons()[j] != 0)
						{
							if(j == elevators[i].GetCurrentFloor())
							{
								for(int k = 0; k < master.GetFloorSummons()[j] && elevators[i].GetCap() < 8;)
								{
									elevators[i].AddCap();
									elevators[i].AddServiced();
									elevators[i].SetLoaded();
									tempPassenger = floors[j].Dequeue();
									tempPassenger.SetEnd(elevators[i].GetTime());
									tempPassenger.ServiceTime();
									master.GetPatronServiceTime(tempPassenger.GetServiceTime());
									elevators[i].AddPassenger(tempPassenger);
									elevators[i].LoadUnload();
									master.AddServicedPatrons();
									master.SubFloorSummons(j);
								}
							}
						}
					}
				}
				if(elevators[i].GetCap() != 8 && elevators[i].LoadedUnloaded())
				{
					elevators[i].Idle();
				}
				if((elevators[i].GetFloorRequests()[1] != 0 && 1 > elevators[i].GetCurrentFloor()) || (elevators[i].GetFloorRequests()[2] != 0 && 2 > elevators[i].GetCurrentFloor())
					|| (elevators[i].GetFloorRequests()[3] != 0 && 3 > elevators[i].GetCurrentFloor()) || (elevators[i].GetFloorRequests()[4] != 0 && 4 > elevators[i].GetCurrentFloor())
					|| (elevators[i].GetFloorRequestsW()[1] != 0 && 1 > elevators[i].GetCurrentFloor()) || (elevators[i].GetFloorRequestsW()[2] != 0 && 2 > elevators[i].GetCurrentFloor())
					|| (elevators[i].GetFloorRequestsW()[3] != 0 && 3 > elevators[i].GetCurrentFloor()) || (elevators[i].GetFloorRequestsW()[4] != 0 && 4 > elevators[i].GetCurrentFloor()))
				{
					elevators[i].SetDirection(true);
					elevators[i].Traverse();
				}
				else if((elevators[i].GetFloorRequests()[0] != 0 && 0 < elevators[i].GetCurrentFloor()) || (elevators[i].GetFloorRequestsW()[0] != 0 && 0 < elevators[i].GetCurrentFloor())
					|| (elevators[i].GetFloorRequests()[1] != 0 && 1 < elevators[i].GetCurrentFloor()) || (elevators[i].GetFloorRequests()[2] != 0 && 2 < elevators[i].GetCurrentFloor())
					|| (elevators[i].GetFloorRequests()[3] != 0 && 3 < elevators[i].GetCurrentFloor()) || (elevators[i].GetFloorRequests()[4] != 0 && 4 < elevators[i].GetCurrentFloor())
					|| (elevators[i].GetFloorRequestsW()[1] != 0 && 1 < elevators[i].GetCurrentFloor()) || (elevators[i].GetFloorRequestsW()[2] != 0 && 2 < elevators[i].GetCurrentFloor())
					|| (elevators[i].GetFloorRequestsW()[3] != 0 && 3 < elevators[i].GetCurrentFloor()) || (elevators[i].GetFloorRequestsW()[4] != 0 && 4 < elevators[i].GetCurrentFloor()))
				{
					elevators[i].SetDirection(false);
					elevators[i].Traverse();
				}
				else if((master.GetFloorSummons()[1] != 0 && 1 > elevators[i].GetCurrentFloor()) || (master.GetFloorSummons()[2] != 0 && 2 > elevators[i].GetCurrentFloor())
					|| (master.GetFloorSummons()[3] != 0 && 3 > elevators[i].GetCurrentFloor()) || (master.GetFloorSummons()[4] != 0 && 4 > elevators[i].GetCurrentFloor())
					|| (master.GetFloorSummonsW()[1] != 0 && 1 > elevators[i].GetCurrentFloor()) || (master.GetFloorSummonsW()[2] != 0 && 2 > elevators[i].GetCurrentFloor())
					|| (master.GetFloorSummonsW()[3] != 0 && 3 > elevators[i].GetCurrentFloor()) || (master.GetFloorSummonsW()[4] != 0 && 4 > elevators[i].GetCurrentFloor()))
				{
					elevators[i].SetDirection(true);
					elevators[i].Traverse();
				}
				else if((master.GetFloorSummons()[0] != 0 && 0 < elevators[i].GetCurrentFloor()) || (master.GetFloorSummonsW()[0] != 0 && 0 < elevators[i].GetCurrentFloor())
					|| (master.GetFloorSummons()[1] != 0 && 1 < elevators[i].GetCurrentFloor()) || (master.GetFloorSummons()[2] != 0 && 2 < elevators[i].GetCurrentFloor())
					|| (master.GetFloorSummons()[3] != 0 && 3 < elevators[i].GetCurrentFloor()) || (master.GetFloorSummons()[4] != 0 && 4 < elevators[i].GetCurrentFloor())
					|| (master.GetFloorSummonsW()[1] != 0 && 1 < elevators[i].GetCurrentFloor()) || (master.GetFloorSummonsW()[2] != 0 && 2 < elevators[i].GetCurrentFloor())
					|| (master.GetFloorSummonsW()[3] != 0 && 3 < elevators[i].GetCurrentFloor()) || (master.GetFloorSummonsW()[4] != 0 && 4 < elevators[i].GetCurrentFloor()))
				{
					elevators[i].SetDirection(false);
					elevators[i].Traverse();
				}
				else if(master.GetFloorSummonsW()[0] == 0 && master.GetFloorSummonsW()[1] == 0 && master.GetFloorSummonsW()[2] == 0 
					&& master.GetFloorSummonsW()[3] == 0 && master.GetFloorSummonsW()[4] == 0 && elevators[i].GetCurrentFloor() != 0 
					&& master.GetFloorSummons()[0] == 0 && master.GetFloorSummons()[1] == 0 && master.GetFloorSummons()[2] == 0 
					&& master.GetFloorSummons()[3] == 0 && master.GetFloorSummons()[4] == 0 && elevators[i].GetCurrentFloor() != 0)
				{
					elevators[i].SetDirection(false);
					elevators[i].Traverse();
				}
			}
		}
		if(master.GetRunning() == false)
		{
			cout << "The master time is " << master.GetTime() << "." << endl;
			for(int i = 0; i < numElev; i++)
			{
				cout << "Number serviced on elevator " << i + 1 << " was " << elevators[i].GetNumServiced() << endl;
			}
			for(int i = 0; i < 5; i++)
			{
				cout << "The number of patrons that got off on floor " << i + 1 << " is " << master.GetSummonsPerFloor()[i] << endl;
			}
			cout << "The total number serviced by the simulation was " << master.GetNumServiced() << endl;
			cout << "The shortest wait time for any elevator patron was " << master.GetShortest() << endl;
			cout << "The longest wait time for any elevator patron was " << master.GetLongest() << endl;
			master.PerUnOne();
			cout << master.GetPerUnOne() << "% was serviced under 1 minute." << endl;
		}
		
	}
	while(master.GetRunning() == true);
	cout << endl << "Please press any key to exit ..." << endl;
	cin.sync();
	_getch();
	return 0;
}