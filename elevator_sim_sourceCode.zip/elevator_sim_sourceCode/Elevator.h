#include"Worker.h"

class Elevator
{
private:
	int currentFloor;
	int cap;
	int maxCap;
	int floorRequests[5];
	int loadUnload;
	int idle;
	int traverse;
	double time;
	bool direction;
	Passenger passengers[8];
	Passenger emptyItem;
	Worker workers[8];
	Worker emptyItemW;
	int floorRequestsW[5];
	bool loaded;
	int numServiced;
public:
	Elevator();
	int GetCurrentFloor();
	int GetCap();
	double GetTime();
	bool Direction();
	void LoadUnload();
	void Traverse();
	void Idle();
	bool CompareTime(double masterTime);
	void SetDirection(bool called);
	void AddCap();
	void SubCap();
	void AddPassenger(Passenger newItem);
	int* GetFloorRequests();
	Passenger SubFloorRequests();
	Worker SubFloorRequestsW();
	void AddWorker(Worker newItem);
	int* GetFloorRequestsW();
	bool LoadedUnloaded();
	void SetLoaded();
	void ResetLoaded();
	void AddServiced();
	int GetNumServiced();
};